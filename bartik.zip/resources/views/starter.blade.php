@extends('template.master')

@section('judulhalaman','Ini Judul')

@section('csstambahan')
<!-- ini adalah tempatnya CSS Tambahan -->

@endsection

@section('kontent')
	<!--Kontent/Koding Disini-->
	<h3>Ini contoh kontent</h3>
	
@endsection

@section('jstambahan')
<!-- ini adalah tempatnya JS Tambahan -->

@endsection
