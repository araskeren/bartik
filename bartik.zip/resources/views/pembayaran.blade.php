@extends('template.master')

@section('judulhalaman','Pembayaran')

@section('csstambahan')
<!-- ini adalah tempatnya CSS Tambahan -->

@endsection

@section('kontent')
	<!--Kontent/Koding Disini-->
	<!-- section -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<!-- Koding disini -->
					<div class=""  >
							<h1>Langkah Berikutnya</h1>
							<h4>Mohon selesaikan pembayaran anda sebelum tanggal 14/08/2018</h4>
					</div>
					<div class="section">
						<!-- container -->
						<div class="container">
							<!-- row -->
							<div class="row">
								<!-- Koding disini -->
								<div class="">
									<h4>Dengan total</h4>
										<h3>Rp.613.000,00</h3>
								</div>
								<div class="">
									<h4>Kode Pembayaran:</h4>
									<h3 style="color:red;">45g45</h3>
								</div>
							</div>
							<!-- /row -->
						</div>
						<!-- /container -->
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /section -->

@endsection

@section('jstambahan')
<!-- ini adalah tempatnya JS Tambahan -->

@endsection
